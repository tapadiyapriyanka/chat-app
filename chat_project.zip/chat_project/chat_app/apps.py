from django.apps import AppConfig


class ChatAppConfig(AppConfig):
    name = 'chat_app'
