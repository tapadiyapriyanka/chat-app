from django.contrib import admin
from .models import chatmessage
# Register your models here.
admin.site.register(chatmessage)
